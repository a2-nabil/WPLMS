<?php 
if ( ! defined( 'ABSPATH' ) ) exit;
?>

</div><!-- END PUSHER -->
</div><!-- END MAIN -->
	<!-- SCRIPTS -->
<?php
wp_footer();
?>   
</body>
</html>